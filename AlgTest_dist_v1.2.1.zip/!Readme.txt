1. Upload proper cap (based on supported JavaCard version) file to your smart card. Upload can be done via GPShell � scripts for selected cards are available. If unsure about supported version, try to upload one with the highest version (AlgTest_v1.2_jc2.2.2.cap) and if upload fail, use lower version) .

2. Run Java application AlgTestJClient. Choose the target reader for card with uploaded AlgTest applet and let it run. CSV file with values separated by the semicolon is created (AlgTest_ATR.csv).

3. Please consider to send me (petr@svenda.com) your results in case your card is not yet in the database at http://www.fi.muni.cz/~xsvenda/jcsupport.html