To obtain list of supported algorithms by your card:
1. Upload AlgTest_v1.7.1_jc222.cap to target card (upload AlgTest_v1.7.1_supportOnly_jc222.cap if you are NOT interested in performance tests)
2. Run java -jar AlgTestJClient.jar
3. Select option 1 -> SUPPORTED ALGORITHMS
4. Fill identification (name) of your card
5. Wait for test to finish (2-10 min)
6. Inspect resulting CSV file