How to obtain list of supported algorithms by your card:
1. Upload AlgTest_v1.7.3_jc222.cap to target card (if your card doesn't support java Card 2.2.2, please use older version AlgTest_v1.7.1)
2. Run java -jar AlgTestJClient.jar
3. Select option 1 -> SUPPORTED ALGORITHMS
4. Fill identification (name) of your card
5. Wait for test to finish (2-10 min)
6. Inspect resulting CSV file
7. Consider sending the result to us at jcalgtest.org so you can contribute to community database and compare the results with others